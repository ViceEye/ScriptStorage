#!/bin/sh

nohup ./forward-server > console.log 2>&1 &
echo $! > app.pid


